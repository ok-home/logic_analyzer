# protocol_scanner.py
import os
import sys
import importlib
from collections import OrderedDict

class ProtocolInfo:
    """Хранит метаданные одного протокола."""
    def __init__(self, mod_name, module):
        self.mod_name = mod_name
        self.module = module
        self.decoder_class = getattr(module, 'Decoder', None)
        if self.decoder_class is None:
            raise ValueError(f"Модуль {mod_name} не содержит класс Decoder")

        self.id = getattr(self.decoder_class, 'id', mod_name)
        self.name = getattr(self.decoder_class, 'name', self.id)
        self.longname = getattr(self.decoder_class, 'longname', self.name)
        self.desc = getattr(self.decoder_class, 'desc', '')

        self.channels = getattr(self.decoder_class, 'channels', ())
        self.optional_channels = getattr(self.decoder_class, 'optional_channels', ())
        self.options = getattr(self.decoder_class, 'options', ())
        self.annotations = getattr(self.decoder_class, 'annotations', ())
        self.annotation_rows = getattr(self.decoder_class, 'annotation_rows', ())
        self.binary = getattr(self.decoder_class, 'binary', ())

    @property
    def all_channels(self):
        """Возвращает объединённый список всех каналов (обязательные + опциональные)."""
        return list(self.channels) + list(self.optional_channels)

    @property
    def num_channels(self):
        """Общее количество каналов, ожидаемых декодером."""
        return len(self.all_channels)


def scan_decoders(decoders_path='decoders'):
    """Сканирует папку decoders и возвращает словарь {id: ProtocolInfo}."""
    protocols = OrderedDict()
    if not os.path.isdir(decoders_path):
        print(f"Папка {decoders_path} не найдена")
        return protocols

    sys.path.insert(0, decoders_path)  # чтобы импортировать модули из папки
    for entry in os.listdir(decoders_path):
        entry_path = os.path.join(decoders_path, entry)
        if not os.path.isdir(entry_path):
            continue
        if entry.startswith('_') or entry.startswith('.'):
            continue
        pd_file = os.path.join(entry_path, 'pd.py')
        if not os.path.isfile(pd_file):
            continue
        try:
            module = importlib.import_module(f"{entry}.pd")
            info = ProtocolInfo(entry, module)
            protocols[info.id] = info
            print(f"Загружен протокол: {info.id} ({info.name})")
        except Exception as e:
            print(f"Ошибка загрузки протокола {entry}: {e}")
    return protocols