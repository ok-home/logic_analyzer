import numpy as np


class UARTDecoder:
    def __init__(self, rx_channel, baudrate=115200, bits=8, parity='none', stopbits=1):
        self.rx_channel = rx_channel
        self.baudrate = baudrate
        self.bits = bits
        self.parity = parity
        self.stopbits = stopbits
        self.annotations = []

    def decode(self, time_axis, samples):
        rx_signal = samples[self.rx_channel, :]
        edges = np.where(np.diff(rx_signal.astype(int)) == -1)[0]
        if len(edges) == 0:
            return []

        bit_time = 1.0 / self.baudrate
        sample_time = time_axis[1] - time_axis[0] if len(time_axis) > 1 else 1e-6
        samples_per_bit = int(bit_time / sample_time)
        if samples_per_bit < 1:
            samples_per_bit = 1

        annotations = []
        for start_idx in edges:
            start_time = time_axis[start_idx]
            middle_offset = int(samples_per_bit / 2)
            data_start_idx = start_idx + middle_offset
            if data_start_idx + (self.bits + self.stopbits) * samples_per_bit >= len(time_axis):
                continue

            byte = 0
            for bit in range(self.bits):
                bit_sample = data_start_idx + bit * samples_per_bit
                if bit_sample < len(rx_signal):
                    bit_val = rx_signal[bit_sample]
                    byte |= (bit_val << bit)
                else:
                    break
            stop_sample = data_start_idx + self.bits * samples_per_bit
            if stop_sample < len(rx_signal) and rx_signal[stop_sample] == 1:
                end_time = time_axis[stop_sample + samples_per_bit - 1] if stop_sample + samples_per_bit -1 < len(time_axis) else time_axis[-1]
                annotations.append((start_time, end_time, byte))
        self.annotations = annotations
        return annotations

    def get_annotations(self):
        return self.annotations