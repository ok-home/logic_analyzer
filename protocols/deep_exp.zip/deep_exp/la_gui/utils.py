import struct

def generate_uart_test_data(filename="uart_test_data.bin", baudrate=115200, sample_rate=10_000_000, message=None):
    if message is None:
        message = "Hello, UART! This is a test message. 0123456789"
    data_bytes = message.encode('utf-8')

    bit_time = 1.0 / baudrate
    sample_time = 1.0 / sample_rate
    samples_per_bit = int(bit_time / sample_time)
    if samples_per_bit < 1:
        samples_per_bit = 1
    print(f"Generating UART test data: baudrate={baudrate}, sample_rate={sample_rate}, samples_per_bit={samples_per_bit}")

    signal = []
    for byte in data_bytes:
        signal.extend([0] * samples_per_bit)
        for bit in range(8):
            bit_val = (byte >> bit) & 1
            signal.extend([bit_val] * samples_per_bit)
        signal.extend([1] * samples_per_bit)
    signal.extend([1] * samples_per_bit * 2)

    total_samples = len(signal)
    bytes_per_sample = 2
    bin_data = bytearray()
    for i in range(total_samples):
        if signal[i]:
            value16 = 0xFFFF
        else:
            value16 = 0x0000
        bin_data.extend(struct.pack('<H', value16))

    with open(filename, "wb") as f:
        f.write(bin_data)
    return filename