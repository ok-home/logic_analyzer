import numpy as np

OUTPUT_ANN = 1
OUTPUT_PYTHON = 2
OUTPUT_BINARY = 3
SRD_CONF_SAMPLERATE = 1

class Decoder:
    def __init__(self):
        self._ensure_attrs()
    
    def _ensure_attrs(self):
        if not hasattr(self, 'out_ann'):
            self.out_ann = None
        if not hasattr(self, 'out_python'):
            self.out_python = None
        if not hasattr(self, 'out_binary'):
            self.out_binary = None
        if not hasattr(self, 'options'):
            self.options = {}
        if not hasattr(self, '_sample_rate'):
            self._sample_rate = None
        if not hasattr(self, '_sample_time'):
            self._sample_time = None
        if not hasattr(self, '_annotations'):
            self._annotations = []
        if not hasattr(self, '_python_output'):
            self._python_output = []
        if not hasattr(self, '_binary_output'):
            self._binary_output = []
        if not hasattr(self, '_channel_names'):
            self._channel_names = {}
        if not hasattr(self, '_channel_indices'):
            self._channel_indices = set()
        if not hasattr(self, '_samples'):
            self._samples = None
        if not hasattr(self, '_time_axis'):
            self._time_axis = None
        if not hasattr(self, '_current_sample'):
            self._current_sample = 0
        if not hasattr(self, '_total_samples'):
            self._total_samples = 0
        if not hasattr(self, 'matched'):
            self.matched = []
        if not hasattr(self, 'samplenum'):
            self.samplenum = 0
        if not hasattr(self, 'startsample'):
            self.startsample = [-1, -1]
        if not hasattr(self, 'ss_packet'):
            self.ss_packet = [None, None]
        if not hasattr(self, 'bit_width'):
            self.bit_width = None
        if not hasattr(self, 'frame_start'):
            self.frame_start = [-1, -1]
        if not hasattr(self, 'frame_len_sample_count'):
            self.frame_len_sample_count = 0
        if not hasattr(self, 'break_min_sample_count'):
            self.break_min_sample_count = 0
        if not hasattr(self, 'idle_start'):
            self.idle_start = [None, None]
        if not hasattr(self, 'cur_frame_bit'):
            self.cur_frame_bit = [None, None]
        if not hasattr(self, 'startbit'):
            self.startbit = [-1, -1]
        if not hasattr(self, 'cur_data_bit'):
            self.cur_data_bit = [0, 0]
        if not hasattr(self, 'datavalue'):
            self.datavalue = [0, 0]
        if not hasattr(self, 'paritybit'):
            self.paritybit = [-1, -1]
        if not hasattr(self, 'stopbits'):
            self.stopbits = [[], []]
        if not hasattr(self, 'state'):
            self.state = ['WAIT FOR START BIT', 'WAIT FOR START BIT']
        if not hasattr(self, 'databits'):
            self.databits = [[], []]
        if not hasattr(self, 'break_start'):
            self.break_start = [None, None]
        if not hasattr(self, 'packet_cache'):
            self.packet_cache = [[], []]
        if not hasattr(self, 'bw'):
            self.bw = 1

    def register(self, out_type):
        self._ensure_attrs()
        if out_type == OUTPUT_ANN:
            self.out_ann = out_type
        elif out_type == OUTPUT_PYTHON:
            self.out_python = out_type
        elif out_type == OUTPUT_BINARY:
            self.out_binary = out_type
        return out_type

    def metadata(self, key, value):
        self._ensure_attrs()
        if key == SRD_CONF_SAMPLERATE:
            self._sample_rate = value
            self._sample_time = 1.0 / value

    def has_channel(self, ch):
        self._ensure_attrs()
        if isinstance(ch, int):
            return ch in self._channel_indices
        elif isinstance(ch, str):
            return ch in self._channel_names
        return False

    def register_channels(self, channel_map):
        self._ensure_attrs()
        self._channel_names = channel_map
        self._channel_indices = set(channel_map.values())

    def set_data(self, samples, time_axis):
        self._ensure_attrs()
        self._samples = samples
        self._time_axis = time_axis
        self._total_samples = samples.shape[1] if samples is not None else 0
        self._current_sample = 0
        self.samplenum = 0
        if self._sample_time is None and len(time_axis) > 1:
            self._sample_time = time_axis[1] - time_axis[0]
            self._sample_rate = 1.0 / self._sample_time

    def put(self, start_sample, end_sample, output_type, data):
        self._ensure_attrs()
        if output_type == OUTPUT_ANN:
            ann_class = data[0]
            if isinstance(data[1], list):
                text = ' '.join(data[1])
            else:
                text = str(data[1])
            self._annotations.append((start_sample, end_sample, ann_class, text))
        elif output_type == OUTPUT_PYTHON:
            self._python_output.append((start_sample, end_sample, data))
        elif output_type == OUTPUT_BINARY:
            self._binary_output.append((start_sample, end_sample, data))

    def get_annotations(self):
        self._ensure_attrs()
        if self._sample_time is None:
            return []
        result = []
        for ss, es, ann_class, text in self._annotations:
            if ann_class == 0 or ann_class == 1:
                result.append((ss * self._sample_time, es * self._sample_time, text))
        return result

    def wait(self, conditions):
        self._ensure_attrs()
        if self._current_sample >= self._total_samples:
            raise StopIteration("No more samples")
        self.matched = [False] * len(conditions)
        start_idx = self._current_sample
        for idx in range(start_idx, self._total_samples):
            for cond_idx, cond in enumerate(conditions):
                if not isinstance(cond, dict):
                    continue
                if len(cond) == 1 and 'skip' in cond:
                    skip = int(cond['skip'])
                    new_idx = idx + skip
                    if new_idx >= self._total_samples:
                        new_idx = self._total_samples - 1
                    self._current_sample = new_idx + 1
                    self.samplenum = new_idx
                    self.matched[cond_idx] = True
                    return (0, {})
                elif len(cond) == 1:
                    pin_spec = list(cond.keys())[0]
                    edge_type = cond[pin_spec]
                    if isinstance(pin_spec, str):
                        if pin_spec not in self._channel_names:
                            continue
                        pin_idx = self._channel_names[pin_spec]
                    else:
                        pin_idx = pin_spec
                    if pin_idx not in self._channel_indices:
                        continue
                    prev = self._samples[pin_idx, idx-1] if idx > 0 else self._samples[pin_idx, 0]
                    curr = self._samples[pin_idx, idx]
                    if edge_type == 'r' and prev == 0 and curr == 1:
                        self._current_sample = idx + 1
                        self.samplenum = idx
                        self.matched[cond_idx] = True
                        return (curr, {pin_idx: curr})
                    if edge_type == 'f' and prev == 1 and curr == 0:
                        self._current_sample = idx + 1
                        self.samplenum = idx
                        self.matched[cond_idx] = True
                        return (curr, {pin_idx: curr})
                    if edge_type == 'e' and prev != curr:
                        self._current_sample = idx + 1
                        self.samplenum = idx
                        self.matched[cond_idx] = True
                        return (curr, {pin_idx: curr})
        raise StopIteration("No more samples")

# Глобальные утилиты
def bitpack(bits):
    return sum([b << i for i, b in enumerate(bits)])

def bitpack_lsb(bits, idx=None):
    if idx is not None:
        bits = [b[idx] for b in bits]
    return bitpack(bits)

def bitpack_msb(bits, idx=None):
    bits = bits[:]
    if idx is not None:
        bits = [b[idx] for b in bits]
    bits.reverse()
    return bitpack(bits)

def bin2int(s):
    return int('0b' + s, 2)

def bcd2int(b):
    return (b & 0x0f) + ((b >> 4) * 10)