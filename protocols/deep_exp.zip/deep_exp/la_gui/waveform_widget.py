import numpy as np
import pyqtgraph as pg
from pyqtgraph import InfiniteLine
from PyQt5.QtWidgets import QWidget, QVBoxLayout
from PyQt5.QtCore import Qt, pyqtSignal


class WaveformWidget(QWidget):
    reference_marker_changed = pyqtSignal(object)
    mouse_moved_with_time = pyqtSignal(object)

    def __init__(self, parent=None):
        super().__init__(parent)
        layout = QVBoxLayout()
        self.setLayout(layout)

        self.graph_widget = pg.PlotWidget()
        self.graph_widget.setLabel('bottom', 'Time', 's')
        self.graph_widget.setLabel('left', 'Channels')
        self.graph_widget.showGrid(x=True, y=False, alpha=0.5)
        self.graph_widget.setMouseEnabled(x=True, y=False)
        layout.addWidget(self.graph_widget)

        self.vline = InfiniteLine(angle=90, movable=False, pen=pg.mkPen('r', width=1, style=Qt.DashLine))
        self.graph_widget.addItem(self.vline)
        self.vline.hide()

        self.reference_line = InfiniteLine(angle=90, movable=False, pen=pg.mkPen('b', width=1, style=Qt.DashLine))
        self.graph_widget.addItem(self.reference_line)
        self.reference_line.hide()

        self.curves = []
        self.reference_time = None

        self.graph_widget.scene().sigMouseMoved.connect(self.on_mouse_move)
        self.graph_widget.scene().sigMouseClicked.connect(self.on_mouse_click)

    def plot_signals(self, samples, time_axis, config):
        if samples is None or time_axis is None:
            return
        for c in self.curves:
            self.graph_widget.removeItem(c)
        self.curves.clear()

        show = config.get('show_channels', list(range(16)))
        if not show:
            return

        ch_height = 1.2
        sig_height = 1.0
        top_margin = (ch_height - sig_height) / 2.0
        y_offsets = np.arange(len(show)-1, -1, -1) * ch_height

        if len(time_axis) > 1:
            dt = time_axis[1] - time_axis[0]
        else:
            dt = 1.0
        x_step = np.append(time_axis, time_axis[-1] + dt)

        for idx, ch in enumerate(show):
            y_vals = samples[ch, :] * sig_height + y_offsets[idx] + top_margin
            curve = self.graph_widget.plot(x_step, y_vals, stepMode=True, pen=pg.mkPen('g', width=1))
            self.curves.append(curve)

        y_min = -ch_height * 0.2
        y_max = len(show) * ch_height + ch_height * 0.2
        self.graph_widget.setYRange(y_min, y_max)

        label_pos = y_offsets + ch_height / 2.0
        ticks = []
        for idx, ch in enumerate(show):
            gpio = config.get('gpio', {}).get(ch, '-1')
            label = f"GPIO{gpio}" if gpio != '-1' else f"CH{ch}"
            ticks.append((label_pos[idx], label))
        self.graph_widget.getAxis('left').setTicks([ticks])

        self.graph_widget.setXRange(time_axis[0], time_axis[-1])
        self.vline.hide()
        self.reference_line.hide()
        self.reference_time = None

    def on_mouse_move(self, pos):
        vb = self.graph_widget.plotItem.vb
        if vb.sceneBoundingRect().contains(pos):
            mouse_point = vb.mapSceneToView(pos)
            t = mouse_point.x()
            self.mouse_moved_with_time.emit(t)
            xlim = self.graph_widget.viewRange()[0]
            if xlim[0] <= t <= xlim[1]:
                self.vline.setPos(t)
                self.vline.show()
            else:
                self.vline.hide()
        else:
            self.mouse_moved_with_time.emit(None)
            self.vline.hide()

    def on_mouse_click(self, event):
        if event.button() == Qt.LeftButton:
            vb = self.graph_widget.plotItem.vb
            pos = event.scenePos()
            if vb.sceneBoundingRect().contains(pos):
                mouse_point = vb.mapSceneToView(pos)
                t = mouse_point.x()
                self.reference_time = t
                self.reference_line.setPos(t)
                self.reference_line.show()
                self.reference_marker_changed.emit(t)
        elif event.button() == Qt.RightButton:
            self.clear_reference_marker()

    def clear_reference_marker(self):
        self.reference_time = None
        self.reference_line.hide()
        self.reference_marker_changed.emit(None)

    def get_reference_time(self):
        return self.reference_time

    def scene(self):
        return self.graph_widget.scene()