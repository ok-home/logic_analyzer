from PyQt5.QtWidgets import QDialog, QFormLayout, QComboBox, QLineEdit, QDialogButtonBox, QCheckBox

class DecoderSettingsDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("UART Decoder Settings")
        self.setModal(True)
        layout = QFormLayout()

        self.channel_combo = QComboBox()
        self.channel_combo.addItems([str(i) for i in range(16)])
        layout.addRow("RX channel:", self.channel_combo)

        self.baud_edit = QLineEdit("115200")
        layout.addRow("Baud rate:", self.baud_edit)

        self.bits_combo = QComboBox()
        self.bits_combo.addItems(["5", "6", "7", "8", "9"])
        layout.addRow("Data bits:", self.bits_combo)

        self.parity_combo = QComboBox()
        self.parity_combo.addItems(["none", "odd", "even", "zero", "one", "ignore"])
        layout.addRow("Parity:", self.parity_combo)

        self.stopbits_combo = QComboBox()
        self.stopbits_combo.addItems(["1", "1.5", "2"])
        layout.addRow("Stop bits:", self.stopbits_combo)

        self.invert_check = QCheckBox()
        layout.addRow("Invert RX:", self.invert_check)

        buttons = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)
        layout.addRow(buttons)

        self.setLayout(layout)

    def get_settings(self):
        stop_str = self.stopbits_combo.currentText()
        if stop_str == "1.5":
            stop_val = 1.5
        else:
            stop_val = float(stop_str)
        return {
            'rx_channel': int(self.channel_combo.currentText()),
            'baudrate': int(self.baud_edit.text()),
            'bits': int(self.bits_combo.currentText()),
            'parity': self.parity_combo.currentText(),
            'stopbits': stop_val,
            'invert': self.invert_check.isChecked(),
        }