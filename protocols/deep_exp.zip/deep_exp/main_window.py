# main_window.py
import sys
import struct
import os
import numpy as np
import pyqtgraph as pg
from PyQt5.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
    QComboBox, QLabel, QSpinBox, QDoubleSpinBox, QCheckBox,
    QPushButton, QFileDialog, QGroupBox, QFormLayout,
    QSplitter, QTextBrowser, QLineEdit
)
from PyQt5.QtCore import Qt

import sigrokdecode_stub as srd
from protocol_scanner import scan_decoders

class SignalViewer(pg.PlotWidget):
    """Виджет для отображения цифровых сигналов и аннотаций."""
    def __init__(self, parent=None):
        super().__init__(parent=parent)
        self.setBackground('w')
        self.showGrid(x=True, y=False)
        self.plot_items = []
        self.annotation_items = []

    def clear_view(self):
        """Очищает график."""
        self.clear()
        self.plot_items = []
        self.annotation_items = []

    def set_data(self, words, samplerate, channels, annotations, ann_color_map):
        self.clear_view()
        num_channels = len(channels)
        if num_channels == 0:
            return

        total_time = len(words) / samplerate
        time = np.arange(len(words)) / samplerate

        # Смещения по вертикали для каждой дорожки
        offsets = np.arange(num_channels) * 1.5

        # Рисуем сигналы
        for i, bit in enumerate(channels):
            values = np.array([(w >> bit) & 1 for w in words], dtype=float)
            values += offsets[i]
            curve = pg.PlotDataItem(time, values, stepMode='right', pen=pg.mkPen(color='b', width=2))
            self.addItem(curve)
            self.plot_items.append(curve)
            # Заливка
            fill = pg.FillBetweenItem(curve, pg.PlotDataItem(time, offsets[i] * np.ones_like(time)),
                                      brush=pg.mkBrush(100, 100, 255, 80))
            self.addItem(fill)

        # Рисуем аннотации
        if annotations:
            for (start, end, ann_class, text) in annotations:
                t_start = start / samplerate
                t_end = end / samplerate
                color = ann_color_map.get(ann_class, '#000')
                rect = pg.LinearRegionItem(values=(t_start, t_end), orientation='vertical',
                                           brush=pg.mkBrush(color), movable=False)
                self.addItem(rect)
                x_center = (t_start + t_end) / 2
                # Текст аннотации под сигналами
                text_item = pg.TextItem(text, anchor=(0.5, 0.5), color='k')
                text_item.setPos(x_center, -1)
                self.addItem(text_item)
                self.annotation_items.append((rect, text_item))

        # Настройка пределов
        y_max = offsets[-1] + 1.5 if len(offsets) > 0 else 1.5
        self.setYRange(-2, y_max)
        self.setLabel('left', 'Channel Level')
        self.setXRange(0, total_time)
        self.setLimits(xMin=0, xMax=total_time)


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Universal Sigrok Decoder GUI")
        self.resize(1200, 900)

        self.decoders = scan_decoders()
        self.current_protocol_info = None

        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        main_layout = QVBoxLayout(central_widget)

        # Верхняя панель
        top_layout = QHBoxLayout()
        top_layout.addWidget(QLabel("Протокол:"))
        self.protocol_combo = QComboBox()
        self.protocol_combo.addItems(list(self.decoders.keys()))
        self.protocol_combo.currentTextChanged.connect(self.on_protocol_changed)
        top_layout.addWidget(self.protocol_combo)

        top_layout.addWidget(QLabel("Samplerate (Гц):"))
        self.samplerate_spin = QDoubleSpinBox()
        self.samplerate_spin.setRange(1, 1e12)
        self.samplerate_spin.setDecimals(0)
        self.samplerate_spin.setValue(1_000_000)
        top_layout.addWidget(self.samplerate_spin)

        self.load_file_btn = QPushButton("Загрузить файл...")
        self.load_file_btn.clicked.connect(self.load_file)
        top_layout.addWidget(self.load_file_btn)

        self.file_label = QLabel("Файл не выбран")
        top_layout.addWidget(self.file_label)

        main_layout.addLayout(top_layout)

        # Панели каналов и опций
        middle_layout = QHBoxLayout()
        self.channels_group = QGroupBox("Каналы")
        self.channels_layout = QFormLayout()
        self.channels_group.setLayout(self.channels_layout)
        middle_layout.addWidget(self.channels_group)

        self.options_group = QGroupBox("Опции")
        self.options_layout = QFormLayout()
        self.options_group.setLayout(self.options_layout)
        middle_layout.addWidget(self.options_group)
        main_layout.addLayout(middle_layout)

        # Кнопка декодирования
        self.decode_btn = QPushButton("Декодировать")
        self.decode_btn.clicked.connect(self.decode)
        main_layout.addWidget(self.decode_btn)

        # Разделитель: график + текстовый вывод
        splitter = QSplitter(Qt.Vertical)
        self.signal_viewer = SignalViewer()
        self.output_browser = QTextBrowser()
        self.output_browser.setOpenExternalLinks(False)
        splitter.addWidget(self.signal_viewer)
        splitter.addWidget(self.output_browser)
        splitter.setSizes([600, 300])
        main_layout.addWidget(splitter)

        if self.decoders:
            self.on_protocol_changed(self.protocol_combo.currentText())

        self.file_path = None
        self.words = None

    def load_file(self):
        path, _ = QFileDialog.getOpenFileName(self, "Выберите бинарный файл", "", "Binary files (*.bin);;All files (*)")
        if path:
            self.file_path = path
            self.file_label.setText(os.path.basename(path))

    def on_protocol_changed(self, proto_id):
        # очистка панелей каналов и опций
        for i in reversed(range(self.channels_layout.count())):
            w = self.channels_layout.itemAt(i).widget()
            if w: w.deleteLater()
        for i in reversed(range(self.options_layout.count())):
            w = self.options_layout.itemAt(i).widget()
            if w: w.deleteLater()

        if proto_id not in self.decoders:
            return
        self.current_protocol_info = self.decoders[proto_id]
        info = self.current_protocol_info

        self.channel_spinboxes = {}
        self.channel_checks = {}
        for idx, ch in enumerate(info.all_channels):
            row = QHBoxLayout()
            label = QLabel(f"{ch['name']} ({ch['desc']})")
            spin = QSpinBox()
            spin.setRange(0, 15)
            spin.setValue(idx)
            row.addWidget(label)
            row.addWidget(spin)
            self.channel_spinboxes[ch['id']] = spin

            if ch in info.optional_channels:
                check = QCheckBox("Использовать")
                check.setChecked(True)
                check.toggled.connect(lambda checked, s=spin: s.setEnabled(checked))
                row.addWidget(check)
                self.channel_checks[ch['id']] = check

            w = QWidget()
            w.setLayout(row)
            self.channels_layout.addRow(w)

        self.option_widgets = {}
        for opt in info.options:
            oid = opt['id']
            desc = opt.get('desc', oid)
            default = opt.get('default')
            values = opt.get('values')
            if values is not None:
                combo = QComboBox()
                for v in values:
                    combo.addItem(str(v))
                if default is not None:
                    idx_combo = combo.findText(str(default))
                    if idx_combo >= 0:
                        combo.setCurrentIndex(idx_combo)
                self.option_widgets[oid] = combo
                self.options_layout.addRow(QLabel(desc + ":"), combo)
            elif isinstance(default, (int, float)):
                if isinstance(default, int):
                    spin = QSpinBox()
                    spin.setRange(-10**9, 10**9)
                    spin.setValue(default)
                else:
                    spin = QDoubleSpinBox()
                    spin.setRange(-10**9, 10**9)
                    spin.setValue(default)
                self.option_widgets[oid] = spin
                self.options_layout.addRow(QLabel(desc + ":"), spin)
            else:
                edit = QLineEdit(str(default) if default else "")
                self.option_widgets[oid] = edit
                self.options_layout.addRow(QLabel(desc + ":"), edit)

    def decode(self):
        if not self.current_protocol_info or not self.file_path:
            self.output_browser.setPlainText("Ошибка: выберите протокол и файл")
            return

        info = self.current_protocol_info
        decoder = info.module.Decoder()

        channels = []
        for ch in info.all_channels:
            if ch in info.optional_channels and ch['id'] in self.channel_checks:
                if not self.channel_checks[ch['id']].isChecked():
                    continue
            channels.append(self.channel_spinboxes[ch['id']].value())
        num_channels = info.num_channels

        options = {}
        for opt in info.options:
            oid = opt['id']
            w = self.option_widgets.get(oid)
            if w is None: continue
            if isinstance(w, QComboBox):
                val = w.currentText()
                # Пробуем преобразовать в число (сначала int, затем float)
                try:
                    val = int(val)
                except ValueError:
                    try:
                        val = float(val)
                    except ValueError:
                        pass
                options[oid] = val
            elif isinstance(w, (QSpinBox, QDoubleSpinBox)):
                options[oid] = w.value()
            elif isinstance(w, QLineEdit):
                options[oid] = w.text()

        try:
            with open(self.file_path, 'rb') as f:
                words = []
                while True:
                    d = f.read(2)
                    if not d: break
                    words.append(struct.unpack('<H', d)[0])
            self.words = words
        except Exception as e:
            self.output_browser.setPlainText(f"Ошибка чтения файла: {e}")
            return

        metadata = {
            'samplerate': self.samplerate_spin.value(),
            'channels': channels,
            'num_channels': num_channels,
            'options': options,
        }

        try:
            results = srd.run_decoder(decoder, words, metadata=metadata)
        except Exception as e:
            import traceback
            self.output_browser.setPlainText(f"Ошибка декодирования:\n{traceback.format_exc()}")
            return

        self._update_graph(words, channels, results, decoder)
        self.display_results(decoder, results)

    def _update_graph(self, words, channels, results, decoder):
        info = self.current_protocol_info
        out_map = decoder.output_protocols
        ann_color_map = {}
        if info.annotation_rows:
            colors = ['#1f77b4','#ff7f0e','#2ca02c','#d62728','#9467bd',
                      '#8c564b','#e377c2','#7f7f7f','#bcbd22','#17becf']
            for row_idx, row in enumerate(info.annotation_rows):
                _, _, indices = row
                for i in indices:
                    ann_color_map[i] = colors[row_idx % len(colors)]

        annotations = []
        for start, end, out_id, data in results:
            if out_map.get(out_id) == 'ann' and isinstance(data, list) and len(data) >= 2:
                annotations.append((start, end, data[0], data[1][0] if data[1] else ''))

        self.signal_viewer.set_data(words, self.samplerate_spin.value(), channels, annotations, ann_color_map)

    def display_results(self, decoder, results):
        info = self.current_protocol_info
        out_map = decoder.output_protocols
        ann_color_map = {}
        if info.annotation_rows:
            colors = ['#1f77b4','#ff7f0e','#2ca02c','#d62728','#9467bd',
                      '#8c564b','#e377c2','#7f7f7f','#bcbd22','#17becf']
            for row_idx, row in enumerate(info.annotation_rows):
                _, _, indices = row
                for i in indices:
                    ann_color_map[i] = colors[row_idx % len(colors)]

        html = '<html><body style="font-family: monospace; font-size: 10pt;">'
        for start, end, out_id, data in results:
            typ = out_map.get(out_id, 'unknown')
            if typ == 'python':
                text, color = f"PYTHON: {data!r}", '#333'
            elif typ == 'binary':
                text, color = f"BIN: {data!r}", '#555'
            elif typ == 'meta':
                text, color = f"META: {data!r}", '#999'
            elif typ == 'ann':
                if isinstance(data, list) and len(data) >= 2:
                    text = f"ANN: {data[1][0] if data[1] else ''}"
                    color = ann_color_map.get(data[0], '#000')
                else:
                    text, color = f"ANN: {data!r}", '#000'
            else:
                text, color = f"{typ}: {data!r}", '#000'
            html += f'<span style="color:{color};">[{start}..{end}] {text}</span><br>'
        html += '</body></html>'
        self.output_browser.setHtml(html)