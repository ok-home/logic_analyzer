# test_i2c.py
import sys
import struct
import os

sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'decoders'))
import sigrokdecode_stub as srd
from i2c import pd   # предполагается, что в папке decoders/i2c лежит pd.py

def read_binary_file(filename):
    words = []
    with open(filename, 'rb') as f:
        while True:
            data = f.read(2)
            if not data:
                break
            word = struct.unpack('<H', data)[0]
            words.append(word)
    return words

FILENAME = 'i2c_test.bin'
SCL = 0
SDA = 1

print(f"Чтение {FILENAME}...")
signal = read_binary_file(FILENAME)
print(f"Загружено {len(signal)} сэмплов.")

decoder = pd.Decoder()
metadata = {
    'samplerate': 1_000_000,
    'channels': [SCL, SDA],
}
results = srd.run_decoder(decoder, signal, metadata=metadata)

print("\nРезультаты декодирования I2C:")
for start, end, out_id, data in results:
    typ = decoder.output_protocols.get(out_id)
    if typ == 'python':
        print(f"[{start}..{end}] PYTHON: {data}")
    elif typ == 'ann':
        print(f"[{start}..{end}] ANN: {data}")