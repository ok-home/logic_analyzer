# generate_timing_test.py
import struct

SAMPLERATE = 1_000_000  # 1 МГц
FREQ = 50_000           # 50 кГц -> период 20 мкс = 20 сэмплов
SAMPLES_HALF = 10

signal = []
for _ in range(20):   # 20 периодов
    signal.extend([1] * SAMPLES_HALF)
    signal.extend([0] * SAMPLES_HALF)

with open('timing_test.bin', 'wb') as f:
    for state in signal:
        f.write(struct.pack('<H', state & 0x01))

print(f"Создан timing_test.bin, длина {len(signal)} сэмплов.")