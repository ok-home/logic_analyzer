# generate_uart_long.py
import struct

SAMPLERATE = 10_000_000   # 10 МГц
BAUDRATE = 115200         # 115200 бод
SAMPLES_PER_BIT = SAMPLERATE / BAUDRATE  # ~86.8

def uart_frame(byte):
    bits = [0]  # start
    for i in range(8):
        bits.append((byte >> i) & 1)
    bits.append(1)  # stop
    return bits

def generate_signal(bits_list, samples_per_bit):
    signal = []
    for bit in bits_list:
        # Используем round для дробного числа семплов
        count = int(round(samples_per_bit))
        signal.extend([bit] * count)
    return signal

# Мусор + idle + данные
signal = []
signal.extend([0] * 2000)   # низкий уровень
signal.extend([1] * 100)    # короткий всплеск
signal.extend([0] * 900)

idle_samples = int(SAMPLES_PER_BIT * 11)  # чуть больше одного кадра
signal.extend([1] * idle_samples)

data_bytes = [0xAA, 0xB1, 0x55] + list(b'HELLO')
for b in data_bytes:
    bits = uart_frame(b)
    signal.extend(generate_signal(bits, SAMPLES_PER_BIT))

signal.extend([1] * idle_samples)

with open('uart_long.bin', 'wb') as f:
    for state in signal:
        word = state & 0x01
        f.write(struct.pack('<H', word))

print(f"Создан uart_long.bin, длина {len(signal)} сэмплов.")
print(f"Ожидаемые байты после мусора: {[hex(b) for b in data_bytes]}")