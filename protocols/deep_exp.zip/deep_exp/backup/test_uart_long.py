# test_uart_long.py
import sys
import struct
import os

sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'decoders'))
import sigrokdecode_stub as srd
from uart import pd

def read_binary_file(filename, channel=0):
    samples = []
    with open(filename, 'rb') as f:
        while True:
            data = f.read(2)
            if not data:
                break
            word = struct.unpack('<H', data)[0]
            state = (word >> channel) & 1
            samples.append(state)
    return samples

FILENAME = 'uart_long.bin'
CHANNEL = 0
SAMPLERATE = 10_000_000
BAUDRATE = 115200

print(f"Чтение {FILENAME}...")
signal = read_binary_file(FILENAME, channel=CHANNEL)
print(f"Загружено {len(signal)} сэмплов.")

decoder = pd.Decoder()
metadata = {
    'samplerate': SAMPLERATE,
    'options': {'baudrate': BAUDRATE}
}
results = srd.run_decoder(decoder, signal, metadata=metadata)

# Соберём DATA и FRAME
data_packets = []
for start, end, out_id, data in results:
    typ = decoder.output_protocols.get(out_id)
    if typ == 'python' and data[0] == 'DATA':
        value = data[2][0]
        valid = False
        for s2, e2, o2, d2 in results:
            if decoder.output_protocols.get(o2) == 'python' and d2[0] == 'FRAME':
                if s2 <= start and e2 >= end:
                    valid = d2[2][1]
                    break
        data_packets.append((start, end, value, valid))

# Покажем первые 20 байт
print("\nДекодированные байты (первые 20):")
for s, e, val, valid in data_packets[:20]:
    status = "" if valid else " /fe"
    print(f"  [{s:>6}..{e:<6}] 0x{val:02x} ({val:3d}){status}")

# Сравнение с ожидаемыми
expected = [0xAA, 0xB1, 0x55] + list(b'HELLO')
decoded = [val for _, _, val, _ in data_packets]
print("\nОжидаемые:", [f"0x{b:02x}" for b in expected])
if decoded == expected:
    print("✅ Все байты совпадают!")
else:
    print("❌ Есть расхождения.")
    if len(decoded) < len(expected):
        print(f"   Декодировано меньше байт ({len(decoded)} вместо {len(expected)}).")