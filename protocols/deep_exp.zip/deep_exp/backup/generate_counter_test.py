# generate_counter_test.py
import struct

SAMPLERATE = 1_000_000   # 1 МГц
FREQ = 50_000            # 50 кГц → период 20 мкс = 20 сэмплов
HALF_PERIOD = SAMPLERATE // (2 * FREQ)  # 10 сэмплов высокого/низкого уровня
NUM_PERIODS = 10

signal = []
for _ in range(NUM_PERIODS):
    signal.extend([1] * HALF_PERIOD)
    signal.extend([0] * HALF_PERIOD)

with open('counter_test.bin', 'wb') as f:
    for state in signal:
        f.write(struct.pack('<H', state & 0x01))

print(f"Создан counter_test.bin, длина {len(signal)} сэмплов.")
print(f"Ожидаемое количество перепадов: {NUM_PERIODS * 2}")