# test_i2s.py
import sys, struct, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'decoders'))
import sigrokdecode_stub as srd
from i2s import pd

SAMPLERATE = 3_072_000
BCLK_BIT = 0
WS_BIT = 1
SD_BIT = 2

def read_binary_file(filename):
    words = []
    with open(filename, 'rb') as f:
        while True:
            data = f.read(2)
            if not data:
                break
            word = struct.unpack('<H', data)[0]
            words.append(word)
    return words

FILENAME = 'i2s_test.bin'
print(f"Чтение {FILENAME}...")
signal = read_binary_file(FILENAME)
print(f"Загружено {len(signal)} сэмплов.")

decoder = pd.Decoder()
metadata = {
    'samplerate': SAMPLERATE,
    'channels': [BCLK_BIT, WS_BIT, SD_BIT],
    'num_channels': 3,
}
results = srd.run_decoder(decoder, signal, metadata=metadata)

print("\nРезультаты декодирования I2S:")
for start, end, out_id, data in results:
    typ = decoder.output_protocols.get(out_id)
    if typ == 'python':
        print(f"[{start}..{end}] PYTHON: {data}")
    elif typ == 'ann':
        print(f"[{start}..{end}] ANN: {data}")