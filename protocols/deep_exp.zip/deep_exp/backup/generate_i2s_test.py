# generate_i2s_test.py
import struct

SAMPLERATE = 3_072_000       # 3.072 МГц, удобно для I2S
FS = 48000                   # частота дискретизации аудио
BCLK_FREQ = 64 * FS          # 3.072 МГц, совпадает с SAMPLERATE → 1 сэмпл на такт BCLK
WS_HALF = 32                 # 32 такта BCLK на половину периода WS (для стерео 16 бит)

BCLK_BIT = 0
WS_BIT = 1
SD_BIT = 2

def make_word(bclk, ws, sd):
    return (bclk << BCLK_BIT) | (ws << WS_BIT) | (sd << SD_BIT)

def repeat(seq, times):
    out = []
    for val in seq:
        out.extend([val] * times)
    return out

def i2s_frame(left, right):
    """Генерирует один полный кадр I2S (левая и правая 16-битные выборки)."""
    seq = []
    # Левая половина (WS=1 для I2S стандартного режима, левый канал)
    ws = 0  # по стандарту I2S: WS=0 -> левый канал
    for bit_pos in range(15, -1, -1):
        bit = (left >> bit_pos) & 1
        seq.append(make_word(0, ws, bit))   # BCLK=0
        seq.append(make_word(1, ws, bit))   # BCLK=1
    # Правая половина (WS=1)
    ws = 1
    for bit_pos in range(15, -1, -1):
        bit = (right >> bit_pos) & 1
        seq.append(make_word(0, ws, bit))
        seq.append(make_word(1, ws, bit))
    return seq

# Генерируем 10 кадров (20 семплов)
signal = []
for i in range(10):
    left = 0x1000 + i       # примеры данных
    right = 0x2000 + i
    signal.extend(i2s_frame(left, right))

# Добавим немного тишины в начале (WS=0, BCLK=0, SD=0)
signal = [make_word(0, 0, 0)] * 64 + signal

with open('i2s_test.bin', 'wb') as f:
    for word in signal:
        f.write(struct.pack('<H', word))

print(f"Создан i2s_test.bin, длина {len(signal)} сэмплов.")
print("Ожидаемые данные: левый 0x1000+..., правый 0x2000+...")