# generate_spi_test.py
import struct

SAMPLERATE = 10_000_000
SCK_FREQ = 1_000_000
HALF_PERIOD = SAMPLERATE // (2 * SCK_FREQ)  # 5

SCK_BIT = 0
MOSI_BIT = 1
CS_BIT = 2
MISO_BIT = 3   # фиктивный вход, всегда 0

def make_word(sck, mosi, cs, miso=0):
    return (sck << SCK_BIT) | (mosi << MOSI_BIT) | (cs << CS_BIT) | (miso << MISO_BIT)

def repeat(seq, times):
    out = []
    for val in seq:
        out.extend([val] * times)
    return out

def spi_transfer_byte(byte):
    """Генерирует передачу одного байта в SPI Mode 0 (CPOL=0, CPHA=0)."""
    seq = []
    for bit_pos in range(7, -1, -1):
        bit = (byte >> bit_pos) & 1
        seq.append(make_word(0, bit, 0))   # SCK=0, MOSI=bit, CS=0
        seq.append(make_word(1, bit, 0))   # SCK=1, фиксация данных
    seq.append(make_word(0, 0, 0))         # SCK=0 после байта
    return seq

signal = []
IDLE = make_word(0, 0, 1)   # CS=1 (неактивен)
signal.extend([IDLE] * 20)

# Активируем CS
CS_ACTIVE = make_word(0, 0, 0)
signal.extend(repeat([CS_ACTIVE], HALF_PERIOD))

data_bytes = [0x9A, 0x56, 0xFF]
for byte in data_bytes:
    signal.extend(repeat(spi_transfer_byte(byte), HALF_PERIOD))

# Деактивируем CS
CS_INACTIVE = make_word(0, 0, 1)
signal.extend(repeat([CS_INACTIVE], HALF_PERIOD))

signal.extend([IDLE] * 20)

with open('spi_test.bin', 'wb') as f:
    for word in signal:
        f.write(struct.pack('<H', word))

print(f"Создан spi_test.bin, длина {len(signal)} сэмплов.")
print(f"Переданные байты: {[hex(b) for b in data_bytes]}")