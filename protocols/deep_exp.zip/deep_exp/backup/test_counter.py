# test_counter.py
import sys, struct, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'decoders'))
import sigrokdecode_stub as srd
from counter import pd

def read_binary_file(filename, channel=0):
    samples = []
    with open(filename, 'rb') as f:
        while True:
            data = f.read(2)
            if not data:
                break
            word = struct.unpack('<H', data)[0]
            state = (word >> channel) & 1
            samples.append(state)
    return samples

FILENAME = 'counter_test.bin'
CHANNEL = 0
print(f"Чтение {FILENAME}...")
signal = read_binary_file(FILENAME, channel=CHANNEL)
print(f"Загружено {len(signal)} сэмплов.")

decoder = pd.Decoder()
metadata = {
    'samplerate': 1_000_000,
    'channels': [CHANNEL],
    'num_channels': 1,
}
results = srd.run_decoder(decoder, signal, metadata=metadata)

print("\nРезультаты декодирования Counter:")
for start, end, out_id, data in results:
    typ = decoder.output_protocols.get(out_id)
    if typ == 'python':
        print(f"[{start}..{end}] PYTHON: {data}")
    elif typ == 'ann':
        print(f"[{start}..{end}] ANN: {data}")