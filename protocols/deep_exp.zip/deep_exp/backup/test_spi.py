# test_spi.py
import sys, struct, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'decoders'))
import sigrokdecode_stub as srd
from spi import pd

SAMPLERATE = 10_000_000
SCK_BIT = 0
MOSI_BIT = 1
CS_BIT = 2
MISO_BIT = 3

def read_binary_file(filename):
    words = []
    with open(filename, 'rb') as f:
        while True:
            data = f.read(2)
            if not data:
                break
            word = struct.unpack('<H', data)[0]
            words.append(word)
    return words

FILENAME = 'spi_test.bin'
print(f"Чтение {FILENAME}...")
signal = read_binary_file(FILENAME)
print(f"Загружено {len(signal)} сэмплов.")

decoder = pd.Decoder()
metadata = {
    'samplerate': SAMPLERATE,
    'channels': [SCK_BIT, MISO_BIT, MOSI_BIT, CS_BIT],  # порядок: clk, miso, mosi, cs
    'num_channels': 4,
}
results = srd.run_decoder(decoder, signal, metadata=metadata)

print("\nРезультаты декодирования SPI:")
for start, end, out_id, data in results:
    typ = decoder.output_protocols.get(out_id)
    if typ == 'python':
        print(f"[{start}..{end}] PYTHON: {data}")
    elif typ == 'ann':
        print(f"[{start}..{end}] ANN: {data}")