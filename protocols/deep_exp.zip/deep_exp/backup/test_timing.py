# test_timing.py
import sys
import struct
import os

sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'decoders'))
import sigrokdecode_stub as srd
from timing import pd

def read_binary_file(filename, channel=0):
    samples = []
    with open(filename, 'rb') as f:
        while True:
            data = f.read(2)
            if not data:
                break
            word = struct.unpack('<H', data)[0]
            state = (word >> channel) & 1
            samples.append(state)
    return samples

FILENAME = 'timing_test.bin'
print(f"Чтение {FILENAME}...")
signal = read_binary_file(FILENAME, channel=0)
print(f"Загружено {len(signal)} сэмплов.")

decoder = pd.Decoder()
results = srd.run_decoder(decoder, signal, metadata={'samplerate': 1_000_000, 'channels': [0]})

print("\nРезультаты декодирования Timing:")
for start, end, out_id, data in results:
    typ = decoder.output_protocols.get(out_id)
    print(f"[{start}..{end}] {typ}: {data}")