# generate_i2c_test.py
import struct

SAMPLERATE = 1_000_000
I2C_FREQ = 100_000
HALF_PERIOD = SAMPLERATE // (2 * I2C_FREQ) * 2  # 10

SCL_BIT = 0
SDA_BIT = 1

def make_word(scl, sda):
    return (scl << SCL_BIT) | (sda << SDA_BIT)

def repeat(seq, times):
    out = []
    for val in seq:
        out.extend([val] * times)
    return out

def idle():
    return [make_word(1, 1)] * 10

def start_condition():
    return [
        make_word(1, 1),
        make_word(1, 0),  # START
        make_word(0, 0),
    ]

def stop_condition():
    return [
        make_word(0, 0),
        make_word(1, 0),
        make_word(1, 1),  # STOP
    ]

def send_byte(byte, ack=True):
    seq = []
    seq.append(make_word(0, 1))  # SCL=0, SDA=1 перед первым битом
    for i in range(8):
        bit = (byte >> (7 - i)) & 1
        seq.append(make_word(0, bit))
        seq.append(make_word(1, bit))
        seq.append(make_word(0, bit))
    ack_bit = 0 if ack else 1
    seq.append(make_word(0, ack_bit))
    seq.append(make_word(1, ack_bit))
    seq.append(make_word(0, ack_bit))
    seq.extend([make_word(0, ack_bit)] * 5)  # дополнительная пауза
    seq.append(make_word(0, 1))  # поднимаем SDA при SCL=0
    return seq

# ---------- Сборка сигнала ----------
signal = []
signal.extend(idle())

# Старт
signal.extend(repeat(start_condition(), HALF_PERIOD))

# Адрес 0x50 (запись) → 0xA0
addr = (0x50 << 1) | 0
signal.extend(repeat(send_byte(addr, ack=True), HALF_PERIOD))

# Данные 0xA5
data = 0xA5
signal.extend(repeat(send_byte(data, ack=True), HALF_PERIOD))

# Стоп
signal.extend(repeat(stop_condition(), HALF_PERIOD))

signal.extend(idle())

with open('i2c_test.bin', 'wb') as f:
    for word in signal:
        f.write(struct.pack('<H', word))

print(f"Создан i2c_test.bin, длина {len(signal)} сэмплов.")
print("Ожидаемая транзакция: START / 0x50 (W) ACK / 0xA5 ACK / STOP")